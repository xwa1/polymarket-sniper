import { NextRequest, NextResponse } from "next/server";

const GAMMA_BASE = "https://gamma-api.polymarket.com";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  const minProb = parseFloat(searchParams.get("minProb") ?? "0.90");
  const maxDays = parseFloat(searchParams.get("maxDays") ?? "2");
  const minVol = parseFloat(searchParams.get("minVol") ?? "1000");

  const now = new Date();
  const maxClose = new Date(now.getTime() + maxDays * 24 * 60 * 60 * 1000);

  // Gamma API acepta end_date_max y end_date_min para filtrar por fecha de cierre
  const params = new URLSearchParams({
    active: "true",
    closed: "false",
    end_date_min: now.toISOString(),
    end_date_max: maxClose.toISOString(),
    limit: "100",
    order: "end_date_asc",
  });

  try {
    const res = await fetch(`${GAMMA_BASE}/markets?${params}`, {
      headers: { Accept: "application/json" },
      // Revalidar cada 5 minutos (Next.js cache)
      next: { revalidate: 300 },
    });

    if (!res.ok) {
      return NextResponse.json(
        { error: `Gamma API error: ${res.status}` },
        { status: 502 }
      );
    }

    const raw: GammaMarket[] = await res.json();

    // Procesar y filtrar
    const markets: ProcessedMarket[] = raw
      .map((m) => {
        // outcomePrices viene como string JSON: "[\"0.95\", \"0.05\"]"
        let prices: number[] = [];
        try {
          const parsed = JSON.parse(m.outcomePrices ?? "[]");
          prices = parsed.map((p: string | number) => parseFloat(String(p)));
        } catch {
          // fallback: usar lastTradePrice
          if (m.lastTradePrice) prices = [m.lastTradePrice];
        }

        const bestProb = prices.length ? Math.max(...prices) : 0;

        // outcomes viene como string JSON: "[\"Yes\", \"No\"]"
        let outcomes: string[] = [];
        try {
          outcomes = JSON.parse(m.outcomes ?? '["Yes","No"]');
        } catch {
          outcomes = ["Yes", "No"];
        }

        // La outcome que tiene mayor probabilidad
        const bestOutcomeIdx = prices.indexOf(bestProb);
        const bestOutcomeName = outcomes[bestOutcomeIdx] ?? "Yes";

        const volumeNum =
          typeof m.volume === "string" ? parseFloat(m.volume) : (m.volume ?? 0);
        const liquidityNum =
          typeof m.liquidity === "string"
            ? parseFloat(m.liquidity)
            : (m.liquidity ?? 0);

        const endDate = m.endDateIso ?? m.endDate ?? "";
        const daysLeft = endDate
          ? (new Date(endDate).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
          : 999;

        return {
          id: m.id,
          question: m.question,
          slug: m.slug,
          category: m.category ?? "",
          endDate,
          daysLeft,
          bestProb,
          bestOutcomeName,
          volume: volumeNum,
          volume24hr: m.volume24hr ?? 0,
          liquidity: liquidityNum,
          bestBid: m.bestBid ?? 0,
          bestAsk: m.bestAsk ?? 0,
          spread: m.spread ?? 0,
          lastTradePrice: m.lastTradePrice ?? 0,
          oneDayPriceChange: m.oneDayPriceChange ?? 0,
        };
      })
      // Filtrar por probabilidad y volumen
      .filter(
        (m) =>
          m.bestProb >= minProb &&
          m.volume >= minVol &&
          m.daysLeft > 0 &&
          m.daysLeft <= maxDays + 0.042 // pequeño margen de horas
      )
      .sort((a, b) => b.bestProb - a.bestProb);

    // Extraer categorías únicas disponibles (para poblar el filtro en el cliente)
    const categories = Array.from(
      new Set(
        raw
          .map((m) => m.category ?? "")
          .filter(Boolean)
      )
    ).sort();

    return NextResponse.json({ markets, categories, fetchedAt: now.toISOString() });
  } catch (err) {
    console.error("[markets route]", err);
    return NextResponse.json({ error: "Internal error" }, { status: 500 });
  }
}

// ── Tipos ──────────────────────────────────────────────────────────────────

interface GammaMarket {
  id: string;
  question: string;
  slug: string;
  category?: string;
  endDate?: string;
  endDateIso?: string;
  active: boolean;
  closed: boolean;
  outcomePrices?: string; // "[\"0.95\",\"0.05\"]"
  outcomes?: string;      // "[\"Yes\",\"No\"]"
  volume?: string | number;
  volume24hr?: number;
  liquidity?: string | number;
  lastTradePrice?: number;
  bestBid?: number;
  bestAsk?: number;
  spread?: number;
  oneDayPriceChange?: number;
}

export interface ProcessedMarket {
  id: string;
  question: string;
  slug: string;
  category: string;
  endDate: string;
  daysLeft: number;
  bestProb: number;
  bestOutcomeName: string;
  volume: number;
  volume24hr: number;
  liquidity: number;
  bestBid: number;
  bestAsk: number;
  spread: number;
  lastTradePrice: number;
  oneDayPriceChange: number;
}
