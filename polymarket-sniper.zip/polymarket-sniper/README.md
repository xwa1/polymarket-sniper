# Polymarket Sniper

Herramienta para detectar mercados de alta probabilidad (≥90%) próximos a resolverse en Polymarket. Ideal para traders que buscan oportunidades de bajo riesgo con 5–15% de ganancia.

## ¿Cómo funciona?

- Consulta la **Gamma API pública de Polymarket** (sin autenticación necesaria)
- Filtra mercados por probabilidad mínima, días restantes y volumen mínimo
- Muestra ganancia potencial, spread, variación diaria del precio y enlace directo

## Campos que usa de la API

| Campo API         | Uso en la app                                      |
| ----------------- | -------------------------------------------------- |
| `outcomePrices`   | Probabilidad de cada outcome (string JSON)         |
| `lastTradePrice`  | Precio más reciente (fallback)                     |
| `endDate`         | Fecha de cierre del mercado                        |
| `volume`          | Volumen total en USDC                              |
| `volume24hr`      | Volumen últimas 24h                                |
| `bestBid/bestAsk` | Spread del order book                              |
| `oneDayPriceChange`| Variación del precio hoy                          |
| `slug`            | Para construir el link polymarket.com/event/{slug} |
| `question`        | Texto de la pregunta del mercado                   |
| `category`        | Categoría (Politics, Sports, Crypto...)            |

## Despliegue en Vercel (gratis, 5 minutos)

### Paso 1 — Sube el código a GitHub
```bash
git init
git add .
git commit -m "init polymarket sniper"
# Crea un repo en github.com y sigue las instrucciones
git remote add origin https://github.com/TU_USUARIO/polymarket-sniper.git
git push -u origin main
```

### Paso 2 — Despliega en Vercel
1. Ve a [vercel.com](https://vercel.com) → "Add New Project"
2. Importa tu repositorio de GitHub
3. Vercel detecta Next.js automáticamente
4. Clic en **Deploy** — listo en ~2 minutos

El proxy (`/api/markets`) corre en el servidor de Vercel, eliminando el problema CORS.

## Desarrollo local

```bash
npm install
npm run dev
# Abre http://localhost:3000
```

## Estructura del proyecto

```
polymarket-sniper/
├── app/
│   ├── api/
│   │   └── markets/
│   │       └── route.ts     ← Proxy a Gamma API (resuelve CORS)
│   ├── page.tsx             ← Interfaz principal
│   └── layout.tsx           ← Layout raíz
├── package.json
├── tsconfig.json
└── next.config.js
```

## Próximos pasos (versión pública)

- [ ] Añadir autorefresco automático cada 5 minutos
- [ ] Filtro por categoría (Politics, Sports, Crypto...)
- [ ] Modo oscuro
- [ ] Alerta por Telegram cuando aparezca un mercado nuevo que cumple los criterios
- [ ] Historial de oportunidades detectadas

## Notas técnicas

- La API route de Next.js hace cache de 5 minutos (`next: { revalidate: 300 }`)
- Sin autenticación requerida para la Gamma API pública
- Rate limiting: Polymarket usa Cloudflare — no hacer más de ~60 req/min
